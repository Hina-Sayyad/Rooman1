# Car-Rental-System

For renting cars as your personal vehicles allowing travelers and people to roam around freely to places having a feel of as their own vehicle.
The purpose is to bring all the company providers  who give these cars on rent on one holistic platform.
It  provides robust and fast deployment of cars who are to be given on rent.

Its a website for booking and renting cars based on perday price and your travel route. 

# Software Requiremants

Django 1.11.2, Python 3.6
virtualenv(Python 3.6), Pycharm Community version,
HTML, CSS and Bootstrap.
